#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="${1:-$PWD}"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_ZIP="$BUNDLE_DIR/UCastBridge-Android-Builder.zip"

if ! command -v unzip >/dev/null 2>&1; then
  echo "ERROR: unzip is not installed in this Codespace."
  exit 1
fi
if [[ ! -f "$SOURCE_ZIP" ]]; then
  echo "ERROR: The bundled UCastBridge-Android-Builder.zip is missing."
  exit 1
fi
if [[ ! -d "$REPO_DIR/.git" ]] && ! git -C "$REPO_DIR" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "ERROR: '$REPO_DIR' is not the root of a Git repository."
  echo "Open the Codespaces terminal in your repository, then run this script again."
  exit 1
fi

REPO_DIR="$(cd "$REPO_DIR" && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

unzip -q "$SOURCE_ZIP" -d "$TEMP_DIR"
PROJECT_DIR="$TEMP_DIR/UCastBridge"

if [[ ! -f "$PROJECT_DIR/app/build.gradle" || ! -f "$PROJECT_DIR/.github/workflows/build-apk.yml" ]]; then
  echo "ERROR: The source archive is incomplete; required Android project/workflow files were not found."
  exit 1
fi

# Copy the project contents, including hidden files and the .github workflow directory.
cp -a "$PROJECT_DIR/." "$REPO_DIR/"

if [[ ! -f "$REPO_DIR/.github/workflows/build-apk.yml" ]]; then
  echo "ERROR: Workflow file was not installed correctly."
  exit 1
fi

# Stage only the project files; do not create a commit or push without the user's action.
git -C "$REPO_DIR" add -A -- . ':!.git'

echo
echo "UCast Bridge project files copied successfully."
echo "Android project: $REPO_DIR/app"
echo "APK workflow:    $REPO_DIR/.github/workflows/build-apk.yml"
echo
echo "Next steps:"
echo "  1. Review staged files: git status --short"
echo "  2. Commit:             git commit -m \"Add UCast Bridge Android project\""
echo "  3. Push:               git push origin main"
echo "  4. Open GitHub Actions and download the UCastBridge-debug-apk artifact."
echo
echo "No commit or push was performed automatically."
